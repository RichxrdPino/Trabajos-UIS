/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;

public class Arbol {
    Nodo raiz;
    private int peso;
    
    public Arbol(){
        this.raiz = null;
    }
    
    public void add(int dato){
        Nodo nuevo = new Nodo(dato);
        
        if (isEmpty()){
            this.raiz = nuevo;
        }else{
            Nodo aux = raiz;
            while(aux != null){
                if (nuevo.dato >= aux.dato){
                    aux = raiz.Der;
                }else{
                    aux = raiz.Izq;
                }
            }
            aux = nuevo;
        }
        peso++;
    }
    
    public boolean isEmpty(){
        return this.raiz == null;
    }
    
    public void verArbol(){
        Nodo aux = raiz;
        while(aux != null){
            
        }
    }
}
