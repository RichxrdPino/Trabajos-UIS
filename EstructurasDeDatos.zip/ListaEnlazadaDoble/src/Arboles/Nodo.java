/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;

public class Nodo {
    public int dato;
    public Nodo Izq;
    public Nodo Der;
    
    public Nodo(int dato){
        this.dato = dato;
        this.Izq = null;
        this.Der = null;
    }
}
