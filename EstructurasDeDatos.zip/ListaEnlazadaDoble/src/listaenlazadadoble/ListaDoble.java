package listaenlazadadoble;

public class ListaDoble {
    private Nodo cabeza, cola;
    private int tamaño;
    
    ListaDoble(){
        this.cabeza = null;
        this.cola = null;
    }
    
    public int getTamaño(){
        return this.tamaño;
    }
    
    public boolean estaVacia(){
        return this.cabeza == null;
    }
    
    public void verListaCabezaCola(){
        String lista = "";
        Nodo nodoAux = this.cabeza;
        
        while (nodoAux != null){
            lista = lista + " " + nodoAux.dato ;
            nodoAux = nodoAux.siguiente;
        }
        System.out.println(lista);
    }
    
    public void verListaColaCabeza(){
        String lista = "";
        Nodo nodoAux = this.cola;
        
        while (nodoAux != null){
            lista = lista + " " + nodoAux.dato ;
            nodoAux = nodoAux.anterior;
        }
        System.out.println(lista);
    }
    
    public void addIni(int dato){
        Nodo nodoIni = new Nodo(dato);
        
        if(this.estaVacia()){
            cola = nodoIni;
        }else{
            nodoIni.siguiente = cabeza;
            cabeza.anterior = nodoIni;
        }
        cabeza = nodoIni;
        
        tamaño++;
    }
    
    public void addFin(int dato){
        Nodo nodoFin = new Nodo(dato);
        
        if(this.estaVacia()){
            cabeza = nodoFin;
            cola = nodoFin;
        }else{
            nodoFin.anterior = cola;
            cola.siguiente = nodoFin;
            cola = nodoFin;
        }
        tamaño++;
    }
    
    public void addIndex(int dato, int idx){
        if(idx == 0){
            this.addIni(dato); //Si indice 0, agregamos al inicio
        }else if(idx==(tamaño-1)){
            this.addFin(dato); //Si indice es el numero de elementos menos 1, agragamos al final.
        }else{
            //Si el indice corresponde ni al final ni al inicio
            
            Nodo nodoIdx = new Nodo(dato);
            Nodo nodoAux = cabeza;
            
            int cont = 0;
            
            while(cont < (idx-1)){
                nodoAux = nodoAux.siguiente;
                cont++;
            }
            nodoAux.siguiente.anterior = nodoIdx;
            nodoIdx.siguiente = nodoAux.siguiente;
            nodoAux.siguiente = nodoIdx;
            nodoIdx.anterior = nodoAux;
            tamaño++;
        }
    }
    
    public void removeIni(){
        
    }
}
