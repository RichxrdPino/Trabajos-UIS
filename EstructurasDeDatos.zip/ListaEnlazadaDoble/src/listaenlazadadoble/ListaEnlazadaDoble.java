/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listaenlazadadoble;

public class ListaEnlazadaDoble {

    public static void main(String[] args) {
        ListaDoble miLista = new ListaDoble();
        System.out.println(miLista.estaVacia());
        
        miLista.addIni(1);
        miLista.addIni(2);
        miLista.addIni(3);
        miLista.addIni(4);
        miLista.addIni(6);
        miLista.addFin(0);
        miLista.addIndex(5, 1);
        System.out.println(miLista.estaVacia());
        miLista.verListaCabezaCola();
        miLista.verListaColaCabeza();
    }
    
}
