/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaenlazadasimple;

public class Lista {
    private Nodo cabeza;
    private int tamaño;
    
    public Lista(){
        this.cabeza = null;
    }
    
    public void addIni(int dato){
        Nodo nodoIni = new Nodo(dato);
        nodoIni.siguiente = cabeza;
        cabeza = nodoIni;
        tamaño++;
    }
    
    public void addFin(int dato){
        Nodo nodoFin = new Nodo(dato);
        Nodo nodoAux = cabeza;
        if(nodoAux == null){
            nodoFin.siguiente = cabeza;
            cabeza = nodoFin;
        }else {
            while(nodoAux.siguiente != null){
                nodoAux = nodoAux.siguiente;
            }
            nodoAux.siguiente = nodoFin;
        }
        tamaño++;
    }
    
    public void addIndex(int dato, int idx){
        if (idx == 0){
            this.addIni(dato);
        }else{
            Nodo nodoIdx = new Nodo(dato);
            Nodo nodoAux = cabeza;
        
            int cont = 0;
            while (cont < (idx-1) && nodoAux.siguiente != null){
                nodoAux = nodoAux.siguiente;
                cont++;
            }
            if (cont==(idx-1)){
                nodoIdx.siguiente = nodoAux.siguiente;
                nodoAux.siguiente = nodoIdx;
            }else{
                System.out.println("Indice inválido");
            }
        }
        tamaño++;
    }
    
    public void removeIni(){
        Nodo nodoIni = cabeza;
        cabeza = nodoIni.siguiente;
        nodoIni.siguiente = null;
        tamaño--;
    }
    
    public void removeFin(){
        Nodo nodoAux = cabeza;
        if(nodoAux == null){
            System.out.println("No puede eliminarse, lista vacía.");
        }else {
            while(nodoAux.siguiente.siguiente != null){
                nodoAux = nodoAux.siguiente;
            }
            nodoAux.siguiente = null;
        }
        tamaño--;
    }
    
    public void removeIndex(int idx){
        Nodo nodoAux = cabeza;
        
        int cont = 0;
        while (cont < (idx-1) && nodoAux.siguiente.siguiente != null){
            nodoAux = nodoAux.siguiente;
            cont++;
        }
        
        Nodo elim = nodoAux.siguiente;
        nodoAux.siguiente = elim.siguiente;
        elim.siguiente = null;
        
        tamaño--;
    }
    
    public void buscarIdx(int idx){
        Nodo nodoAux = cabeza;
        
        int cont = 0;
        while (cont < idx && nodoAux.siguiente != null){
            nodoAux = nodoAux.siguiente;
            cont++;
        }
        
        if(idx+1 > this.tamaño){
            System.out.println("Indice inválido");
        }else{
            System.out.println(nodoAux.dato);
        }
        
        
    }
    
    public void buscarDato(int dato){
        Nodo nodoAux = cabeza;
        int cont = 0;
        String lista = "";
        
        while (nodoAux.siguiente != null){
            if (nodoAux.dato == dato){
                lista = lista + " " + (cont);
            }
            nodoAux = nodoAux.siguiente;
            cont++;
        }
        if (nodoAux.dato == dato){
                lista = lista + " " + (cont);
            }
            nodoAux = nodoAux.siguiente;
            cont++;
        System.out.println(lista);
    }
    
    public void verLista(){
        Nodo nodoAux = cabeza;
        String lista = "";
        
        while (nodoAux != null){
            lista = lista + " " + nodoAux.dato ;
            nodoAux = nodoAux.siguiente;
        }
        System.out.println(lista);
        
    }
}
