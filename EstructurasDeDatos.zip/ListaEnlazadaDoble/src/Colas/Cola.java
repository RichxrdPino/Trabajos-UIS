/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Colas;

public class Cola {
    private Nodo inicio;
    private Nodo fin;
    public int tamano;
    
    public Cola(){
        inicio = fin = null;
        tamano = 0;
    }
    
    public void enqueue(int dato){
        Nodo nuevo = new Nodo(dato);
        
        if (this.fin == null){
            inicio = nuevo;
        }else{
            fin.siguiente = nuevo;
        }
        
        fin = nuevo;
        tamano++;
    }
    
    public void dequeue(){
        
        if(isEmpty()){
            System.out.println("La cola está vacia");
        }else{
            Nodo aux = inicio;
        
            inicio = inicio.siguiente;
            aux.siguiente = null;
            tamano--;
        }
    }
    
    public int peak(){
        return this.inicio.dato;
    }
    
    public boolean isEmpty(){
        return (this.inicio == null);
    }
    
    public void vaciarCola(){
        while(!isEmpty()){
            dequeue();
        }
    }
    
    public void verLista(){
        Nodo nodoAux = inicio;
        String lista = "";
        
        while (nodoAux != null){
            lista = lista + " " + nodoAux.dato ;
            nodoAux = nodoAux.siguiente;
        }
        System.out.println(lista);
        
    }
}
