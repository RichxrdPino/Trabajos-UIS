/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Colas;

public class Colas {
    public static void main(String[] args) {
        Cola cola1 = new Cola();
        
        cola1.enqueue(1);
        cola1.enqueue(3);
        cola1.enqueue(4);
        cola1.dequeue();
        
        cola1.vaciarCola();
        
        cola1.verLista();
    }
}
