/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listaenlazadasimple;

public class ListaEnlazadaSimple {

    public static void main(String[] args) {
        Lista miLista = new Lista();
        
        miLista.addIni(1);
        miLista.addFin(2);
        miLista.addFin(4);
        miLista.addIndex(3, 2);
        miLista.verLista();
        
        miLista.removeIni();
        miLista.removeFin();
        miLista.verLista();
        
        miLista.addFin(4);
        miLista.removeIndex(1);
        miLista.verLista();
        
        miLista.addFin(5);
        miLista.addFin(6);
        miLista.addFin(7);
        miLista.addFin(8);
        miLista.addIni(1);
        miLista.addIndex(3, 2);
        miLista.addFin(7);
        miLista.addFin(7);
        miLista.verLista();
        
        miLista.buscarIdx(0);
        miLista.buscarIdx(1);
        miLista.buscarIdx(2);
        miLista.buscarIdx(8);
        
        miLista.buscarDato(7);
    }
    
}
